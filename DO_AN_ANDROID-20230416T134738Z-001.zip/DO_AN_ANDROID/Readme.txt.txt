1. Trần Minh Phong
2. Ngô Thanh Phong
3. Đậu Sơn Nam
4. Hồ Phương Nam
5. Cao Minh Thắng